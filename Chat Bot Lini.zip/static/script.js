const menuBtn =
    document.getElementById("menuBtn");

const sidebar =
    document.getElementById("sidebar");

const overlay =
    document.getElementById("overlay");

const chatArea =
    document.getElementById("chatArea");

const input =
    document.getElementById("messageInput");

const sendBtn =
    document.getElementById("sendBtn");

const historyList =
    document.getElementById("historyList");

const newChatBtn =
    document.getElementById("newChatBtn");

/* =========================
   STORAGE
========================= */

let chats =
    JSON.parse(
        localStorage.getItem(
            "sunnbee_chats"
        )
    ) || [];

let currentChatId = null;

/* =========================
   REMOVE OLD TEMPLATE
========================= */

chats = chats.filter(chat => {

    return (
        chat.title &&
        chat.title !== "New Chat ☀️"
    );
});

/* =========================
   SIDEBAR
========================= */

function openSidebar() {

    sidebar.classList.add(
        "active"
    );

    overlay.classList.add(
        "active"
    );
}

function closeSidebar() {

    sidebar.classList.remove(
        "active"
    );

    overlay.classList.remove(
        "active"
    );
}

menuBtn.onclick = () => {

    if(
        sidebar.classList.contains(
            "active"
        )
    ) {

        closeSidebar();

    } else {

        openSidebar();
    }
};

overlay.onclick = () => {

    closeSidebar();
};

/* =========================
   SAVE CHAT
========================= */

function saveChats() {

    localStorage.setItem(

        "sunnbee_chats",

        JSON.stringify(chats)
    );
}

/* =========================
   NEW CHAT
========================= */

function createNewChat() {

    // RESET ACTIVE CHAT

    currentChatId = null;

    const chat = {

        id: Date.now(),

        title: null,

        messages:[]
    };

    chats.unshift(chat);

    currentChatId =
        chat.id;

    saveChats();

    renderHistory();

    renderMessages();

    input.value = "";

    // MOBILE AUTO CLOSE

    if(window.innerWidth < 768){

        closeSidebar();
    }
}

/* =========================
   FORCE BUTTON FIX
========================= */

newChatBtn.onclick = () => {

    createNewChat();
};

/* =========================
   RENDER HISTORY
========================= */

function renderHistory() {

    historyList.innerHTML = "";

    chats.forEach(chat => {

        // SKIP EMPTY CHAT

        if(
            !chat.title ||
            chat.title.trim() === ""
        ) {
            return;
        }

        const item =
            document.createElement("div");

        item.className =
            "history-item";

        item.innerText =
            chat.title;

        item.onclick = () => {

            currentChatId =
                chat.id;

            renderMessages();

            if(window.innerWidth < 768){

                closeSidebar();
            }
        };

        historyList.appendChild(
            item
        );
    });
}

/* =========================
   RENDER MESSAGE
========================= */

function renderMessages() {

    chatArea.innerHTML = "";

    const currentChat =
        chats.find(
            c => c.id === currentChatId
        );

    // EMPTY STATE

    if(!currentChat) {

        chatArea.innerHTML = `
            <div class="message-row">

                <img
                    class="reaction-img"
                    src="static/reactions/happy.png"
                >

                <div class="bot-message">

                    Haiii bestieee ☀️💖
                    <br><br>

                    Aku SunnBee ✨

                </div>

            </div>
        `;

        return;
    }

    // EMPTY CHAT

    if(currentChat.messages.length === 0){

        chatArea.innerHTML = `
            <div class="message-row">

                <img
                    class="reaction-img"
                    src="static/reactions/happy.png"
                >

                <div class="bot-message">

                    Haiii bestieee ☀️💖
                    <br><br>

                    Aku SunnBee ✨

                </div>

            </div>
        `;

        return;
    }

    currentChat.messages.forEach(msg => {

        // USER

        if(msg.role === "user") {

            const userBubble =
                document.createElement("div");

            userBubble.className =
                "user-message";

            userBubble.innerText =
                msg.content;

            chatArea.appendChild(
                userBubble
            );

        } else {

            // BOT

            const botRow =
                document.createElement("div");

            botRow.className =
                "message-row";

            botRow.innerHTML = `
                <img
                    class="reaction-img"
                    src="static/reactions/${msg.reaction || "happy.png"}"
                >

                <div class="bot-message">
                    ${msg.content}
                </div>
            `;

            chatArea.appendChild(
                botRow
            );
        }
    });

    chatArea.scrollTop =
        chatArea.scrollHeight;
}

/* =========================
   SEND MESSAGE
========================= */

async function sendMessage() {

    const message =
        input.value.trim();

    if(message === "")
        return;

    // AUTO CREATE CHAT

    if(currentChatId === null){

        createNewChat();
    }

    const currentChat =
        chats.find(
            c => c.id === currentChatId
        );

    /* USER MESSAGE */

    currentChat.messages.push({

        role:"user",

        content:message
    });

    // AUTO TITLE

    if(!currentChat.title) {

        currentChat.title =
            message.substring(0,25);
    }

    renderHistory();

    renderMessages();

    input.value = "";

    /* =========================
       TYPING
    ========================= */

    const typing =
        document.createElement("div");

    typing.className =
        "message-row";

    typing.id =
        "typingBubble";

    typing.innerHTML = `
        <img
            class="reaction-img"
            src="static/reactions/typing.png"
        >

        <div class="bot-message">
            SunnBee lagi mikirrr... ☀️
        </div>
    `;

    chatArea.appendChild(
        typing
    );

    chatArea.scrollTop =
        chatArea.scrollHeight;

    try {

        const response =
            await fetch("/chat", {

                method:"POST",

                headers:{
                    "Content-Type":
                    "application/json"
                },

                body:JSON.stringify({

                    message:message
                })
            });

        const data =
            await response.json();

        typing.remove();

        /* =========================
           AUTO REACTION
        ========================= */

        let reaction =
            "happy.png";

        const reply =
            data.reply.toLowerCase();

        // SAD

        if(
            reply.includes("sedih") ||
            reply.includes("😭") ||
            reply.includes("capek")
        ){

            reaction = "sad.png";
        }

        // LOVE

        if(
            reply.includes("sayang") ||
            reply.includes("💕") ||
            reply.includes("❤️")
        ){

            reaction = "love.png";
        }

        // LAUGH

        if(
            reply.includes("wkwk") ||
            reply.includes("haha") ||
            reply.includes("🤣")
        ){

            reaction = "laugh.png";
        }

        // SHOCK

        if(
            reply.includes("gila") ||
            reply.includes("💀")
        ){

            reaction = "shock.png";
        }

        // CONFUSED

        if(
            reply.includes("?") ||
            reply.includes("bingung")
        ){

            reaction = "confused.png";
        }

        // ANGRY

        if(
            reply.includes("marah") ||
            reply.includes("kesel")
        ){

            reaction = "angry.png";
        }

        /* =========================
           BOT MESSAGE
        ========================= */

        currentChat.messages.push({

            role:"bot",

            content:data.reply,

            reaction:reaction
        });

        saveChats();

        renderMessages();

    } catch(error) {

        typing.remove();

        const errorBubble =
            document.createElement("div");

        errorBubble.className =
            "message-row";

        errorBubble.innerHTML = `
            <img
                class="reaction-img"
                src="static/reactions/confused.png"
            >

            <div class="bot-message">
                Server error 😭
            </div>
        `;

        chatArea.appendChild(
            errorBubble
        );
    }
}

/* =========================
   BUTTON
========================= */

sendBtn.onclick = () => {

    sendMessage();
};

/* =========================
   ENTER
========================= */

input.addEventListener(
    "keypress",
    (e) => {

        if(e.key === "Enter") {

            sendMessage();
        }
    }
);

/* =========================
   INIT
========================= */

renderHistory();

renderMessages();